// Central type definitions shared across the dashboard.

export type BotState = "online" | "offline" | "starting" | "stopping";

export interface BotStatus {
  discord: BotState;
  whatsapp: BotState;
  /** ISO timestamp of when the current state began, used to compute uptime. */
  since?: string;
}

export interface BotStats {
  cpuPercent: number;
  ramUsedMb: number;
  ramTotalMb: number;
  uptimeSeconds: number;
}

export interface LogEntry {
  id: string;
  timestamp: string;
  level: "info" | "warn" | "error" | "debug";
  source: "discord" | "whatsapp" | "system";
  message: string;
}

export interface QrResponse {
  /** Base64 data URL (image/png) or null if WhatsApp is already authenticated. */
  qr: string | null;
  authenticated: boolean;
}

export interface DiscordServersResponse {
  count: number;
  servers: { id: string; name: string; memberCount: number }[];
}

export interface WhatsappGroupsResponse {
  count: number;
  groups: { id: string; name: string; participantCount: number }[];
}

export interface ApiSettings {
  baseUrl: string;
  hasToken: boolean;
}

export interface EnvVar {
  key: string;
  value: string;
}

export interface FileEntry {
  name: string;
  path: string;
  type: "file" | "directory";
  sizeBytes?: number;
  modifiedAt?: string;
}

/** Generic envelope used by our own /app/api proxy routes. */
export interface ApiResult<T> {
  ok: boolean;
  data?: T;
  error?: string;
}
