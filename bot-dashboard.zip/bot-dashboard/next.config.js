/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // The Termux backend is reached via NEXT_PUBLIC_API_BASE_URL on the client,
  // or proxied through /app/api/proxy when CORS/HTTPS issues require a server hop.
};

module.exports = nextConfig;
