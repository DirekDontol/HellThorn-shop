// Thin wrapper around fetch that talks to the dashboard's own /api/proxy
// route. We always go through the proxy so that:
//  - the bearer token never has to live in client-side JS
//  - we get a single place to normalize errors and timeouts
//  - CORS issues with the Termux device are avoided

export class ApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.name = "ApiError";
    this.status = status;
  }
}

interface RequestOptions {
  method?: "GET" | "POST" | "PUT" | "DELETE";
  body?: unknown;
  /** Path on the upstream Termux API, e.g. "/status" */
  path: string;
  /** Abort the request after this many ms (default 10s, logs use longer). */
  timeoutMs?: number;
}

export async function apiRequest<T>({
  method = "GET",
  body,
  path,
  timeoutMs = 10000,
}: RequestOptions): Promise<T> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const res = await fetch(`/api/proxy?path=${encodeURIComponent(path)}`, {
      method,
      headers: { "Content-Type": "application/json" },
      body: body ? JSON.stringify(body) : undefined,
      signal: controller.signal,
      cache: "no-store",
    });

    const text = await res.text();
    const json = text ? JSON.parse(text) : {};

    if (!res.ok) {
      throw new ApiError(json?.error || `Request failed (${res.status})`, res.status);
    }
    return json as T;
  } catch (err) {
    if (err instanceof ApiError) throw err;
    if (err instanceof DOMException && err.name === "AbortError") {
      throw new ApiError("Request timed out. Is the bot device reachable?", 408);
    }
    throw new ApiError(
      err instanceof Error ? err.message : "Unknown network error",
      0,
    );
  } finally {
    clearTimeout(timer);
  }
}
