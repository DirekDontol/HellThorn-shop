// Minimal session handling using a signed cookie (HMAC-SHA256). No external
// auth library needed for a single-admin dashboard — keeps the dependency
// surface small while still being tamper-proof.

import { cookies } from "next/headers";
import crypto from "crypto";

const COOKIE_NAME = "bot_dash_session";
const MAX_AGE = 60 * 60 * 12; // 12 hours

function getSecret(): string {
  const secret = process.env.SESSION_SECRET;
  if (!secret) {
    throw new Error("SESSION_SECRET is not configured");
  }
  return secret;
}

function sign(value: string): string {
  const sig = crypto.createHmac("sha256", getSecret()).update(value).digest("hex");
  return `${value}.${sig}`;
}

function verify(signed: string): string | null {
  const idx = signed.lastIndexOf(".");
  if (idx === -1) return null;
  const value = signed.slice(0, idx);
  const sig = signed.slice(idx + 1);
  const expected = crypto.createHmac("sha256", getSecret()).update(value).digest("hex");
  const sigBuf = Buffer.from(sig);
  const expBuf = Buffer.from(expected);
  if (sigBuf.length !== expBuf.length) return null;
  return crypto.timingSafeEqual(sigBuf, expBuf) ? value : null;
}

export function createSessionCookie(username: string) {
  const payload = `${username}:${Date.now() + MAX_AGE * 1000}`;
  const token = sign(payload);
  cookies().set(COOKIE_NAME, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: MAX_AGE,
  });
}

export function clearSessionCookie() {
  cookies().delete(COOKIE_NAME);
}

export function getSession(): { username: string } | null {
  const token = cookies().get(COOKIE_NAME)?.value;
  if (!token) return null;
  const payload = verify(token);
  if (!payload) return null;
  const [username, expiresAt] = payload.split(":");
  if (!username || !expiresAt || Date.now() > Number(expiresAt)) return null;
  return { username };
}
