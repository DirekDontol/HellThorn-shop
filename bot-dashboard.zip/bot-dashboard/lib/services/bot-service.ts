// Service layer: one typed function per Termux REST endpoint.
// Components/hooks should never call apiRequest directly — always go
// through these functions so the contract with the backend lives in one file.

import { apiRequest } from "./api-client";
import type {
  BotStatus,
  BotStats,
  LogEntry,
  QrResponse,
  DiscordServersResponse,
  WhatsappGroupsResponse,
} from "@/types";

export const botService = {
  getStatus: () => apiRequest<BotStatus>({ path: "/status" }),

  start: () => apiRequest<{ ok: boolean }>({ path: "/start", method: "POST" }),

  stop: () => apiRequest<{ ok: boolean }>({ path: "/stop", method: "POST" }),

  restart: () =>
    apiRequest<{ ok: boolean }>({ path: "/restart", method: "POST" }),

  /** Force restart: same endpoint, with a flag the backend can use to kill -9 first. */
  forceRestart: () =>
    apiRequest<{ ok: boolean }>({
      path: "/restart",
      method: "POST",
      body: { force: true },
    }),

  getLogs: (limit = 200) =>
    apiRequest<LogEntry[]>({ path: `/logs?limit=${limit}` }),

  getStats: () => apiRequest<BotStats>({ path: "/stats" }),

  getQr: () => apiRequest<QrResponse>({ path: "/qr" }),

  getServers: () => apiRequest<DiscordServersResponse>({ path: "/servers" }),

  getGroups: () => apiRequest<WhatsappGroupsResponse>({ path: "/groups" }),
};
