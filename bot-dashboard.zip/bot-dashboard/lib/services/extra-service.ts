// These two features (Environment Variables editor and File Manager) were
// requested in the spec but no endpoint was given for them. They're wired up
// against a conventional REST shape (/env, /files) so they work as soon as
// you add matching routes to the Termux-side API. Adjust paths here if your
// backend differs — this is the only file that needs to change.

import { apiRequest } from "./api-client";
import type { EnvVar, FileEntry } from "@/types";

export const envService = {
  list: () => apiRequest<EnvVar[]>({ path: "/env" }),

  update: (vars: EnvVar[]) =>
    apiRequest<{ ok: boolean }>({ path: "/env", method: "PUT", body: { vars } }),
};

export const fileService = {
  list: (dir = "/") =>
    apiRequest<FileEntry[]>({ path: `/files?dir=${encodeURIComponent(dir)}` }),

  read: (path: string) =>
    apiRequest<{ content: string }>({
      path: `/files/content?path=${encodeURIComponent(path)}`,
    }),

  write: (path: string, content: string) =>
    apiRequest<{ ok: boolean }>({
      path: "/files/content",
      method: "PUT",
      body: { path, content },
    }),

  remove: (path: string) =>
    apiRequest<{ ok: boolean }>({
      path: `/files?path=${encodeURIComponent(path)}`,
      method: "DELETE",
    }),
};
