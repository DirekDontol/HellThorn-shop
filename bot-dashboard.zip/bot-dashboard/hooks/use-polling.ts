"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { ApiError } from "@/lib/api-client";

interface UsePollingOptions {
  /** Poll interval in ms. Set to 0 to disable auto-refresh. */
  intervalMs?: number;
  enabled?: boolean;
}

interface PollingResult<T> {
  data: T | null;
  error: string | null;
  loading: boolean;
  refresh: () => void;
}

/**
 * Generic polling hook: runs `fetcher` immediately, then again every
 * `intervalMs`. Used by every dashboard widget that needs live data
 * (status, stats, logs, QR) without duplicating interval/cleanup logic.
 */
export function usePolling<T>(
  fetcher: () => Promise<T>,
  { intervalMs = 5000, enabled = true }: UsePollingOptions = {},
): PollingResult<T> {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const fetcherRef = useRef(fetcher);
  fetcherRef.current = fetcher;

  const run = useCallback(async () => {
    try {
      const result = await fetcherRef.current();
      setData(result);
      setError(null);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Unexpected error");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (!enabled) return;
    setLoading(true);
    run();
    if (!intervalMs) return;
    const id = setInterval(run, intervalMs);
    return () => clearInterval(id);
  }, [run, intervalMs, enabled]);

  return { data, error, loading, refresh: run };
}
