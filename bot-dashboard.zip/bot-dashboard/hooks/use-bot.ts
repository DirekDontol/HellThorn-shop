"use client";

import { useCallback, useState } from "react";
import { toast } from "sonner";
import { usePolling } from "./use-polling";
import { botService } from "@/lib/services/bot-service";
import { ApiError } from "@/lib/api-client";

export function useBotStatus() {
  return usePolling(botService.getStatus, { intervalMs: 5000 });
}

export function useBotStats() {
  return usePolling(botService.getStats, { intervalMs: 4000 });
}

export function useLogs(autoRefresh: boolean) {
  return usePolling(() => botService.getLogs(300), {
    intervalMs: autoRefresh ? 3000 : 0,
  });
}

export function useQr() {
  return usePolling(botService.getQr, { intervalMs: 6000 });
}

export function useServers() {
  return usePolling(botService.getServers, { intervalMs: 15000 });
}

export function useGroups() {
  return usePolling(botService.getGroups, { intervalMs: 15000 });
}

type Action = "start" | "stop" | "restart" | "forceRestart";

/** Wraps the four control actions with loading state + toast feedback. */
export function useBotActions(onDone?: () => void) {
  const [pending, setPending] = useState<Action | null>(null);

  const run = useCallback(
    async (action: Action, fn: () => Promise<{ ok: boolean }>, successMsg: string) => {
      setPending(action);
      try {
        await fn();
        toast.success(successMsg);
        onDone?.();
      } catch (err) {
        toast.error(err instanceof ApiError ? err.message : "Action failed");
      } finally {
        setPending(null);
      }
    },
    [onDone],
  );

  return {
    pending,
    start: () => run("start", botService.start, "Bot starting..."),
    stop: () => run("stop", botService.stop, "Bot stopping..."),
    restart: () => run("restart", botService.restart, "Bot restarting..."),
    forceRestart: () =>
      run("forceRestart", botService.forceRestart, "Force restart triggered"),
  };
}
