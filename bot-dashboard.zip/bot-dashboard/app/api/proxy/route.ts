// Single proxy endpoint that forwards requests to the Termux-hosted bot API.
// This is what keeps API_BEARER_TOKEN out of the browser entirely: every
// dashboard request hits /api/proxy, which is authenticated by the session
// cookie, then re-signed with the Bearer token server-side before being
// forwarded upstream.

import { NextRequest, NextResponse } from "next/server";
import { getSession } from "@/lib/session";

const ALLOWED_PATH_PREFIXES = [
  "/status",
  "/start",
  "/stop",
  "/restart",
  "/logs",
  "/stats",
  "/qr",
  "/servers",
  "/groups",
  "/env",
  "/files",
];

function isAllowed(path: string): boolean {
  return ALLOWED_PATH_PREFIXES.some((p) => path === p || path.startsWith(`${p}?`) || path.startsWith(`${p}/`));
}

async function forward(req: NextRequest) {
  const session = getSession();
  if (!session) {
    return NextResponse.json({ ok: false, error: "Not authenticated" }, { status: 401 });
  }

  const path = req.nextUrl.searchParams.get("path");
  if (!path || !isAllowed(path)) {
    return NextResponse.json({ ok: false, error: "Invalid or disallowed path" }, { status: 400 });
  }

  const baseUrl = process.env.NEXT_PUBLIC_API_BASE_URL;
  const token = process.env.API_BEARER_TOKEN;
  if (!baseUrl) {
    return NextResponse.json(
      { ok: false, error: "NEXT_PUBLIC_API_BASE_URL is not configured" },
      { status: 500 },
    );
  }

  const upstreamUrl = `${baseUrl.replace(/\/$/, "")}${path}`;
  const body = req.method === "GET" || req.method === "DELETE" ? undefined : await req.text();

  try {
    const upstreamRes = await fetch(upstreamUrl, {
      method: req.method,
      headers: {
        "Content-Type": "application/json",
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      body,
      cache: "no-store",
      signal: AbortSignal.timeout(15000),
    });

    const text = await upstreamRes.text();
    return new NextResponse(text, {
      status: upstreamRes.status,
      headers: { "Content-Type": "application/json" },
    });
  } catch (err) {
    return NextResponse.json(
      {
        ok: false,
        error:
          err instanceof Error
            ? `Upstream unreachable: ${err.message}`
            : "Upstream unreachable",
      },
      { status: 502 },
    );
  }
}

export { forward as GET, forward as POST, forward as PUT, forward as DELETE };
