"use client";

import { useEffect, useState } from "react";
import { Folder, File as FileIcon, ArrowLeft, Trash2, Save, X } from "lucide-react";
import { toast } from "sonner";
import { AppShell } from "@/components/layout/app-shell";
import { Topbar } from "@/components/layout/topbar";
import { Card, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FullPageLoader } from "@/components/ui/loaders";
import { ErrorState } from "@/components/ui/error-state";
import { fileService } from "@/lib/services/extra-service";
import { ApiError } from "@/lib/api-client";
import { formatBytes } from "@/lib/utils";
import type { FileEntry } from "@/types";

export default function FilesPage() {
  const [dir, setDir] = useState("/");
  const [entries, setEntries] = useState<FileEntry[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [editing, setEditing] = useState<{ path: string; content: string } | null>(null);
  const [saving, setSaving] = useState(false);

  const load = async (path: string) => {
    setError(null);
    setEntries(null);
    try {
      setEntries(await fileService.list(path));
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Failed to list files");
    }
  };

  useEffect(() => {
    load(dir);
  }, [dir]);

  const openEntry = async (entry: FileEntry) => {
    if (entry.type === "directory") {
      setDir(entry.path);
      return;
    }
    try {
      const { content } = await fileService.read(entry.path);
      setEditing({ path: entry.path, content });
    } catch (err) {
      toast.error(err instanceof ApiError ? err.message : "Failed to read file");
    }
  };

  const saveFile = async () => {
    if (!editing) return;
    setSaving(true);
    try {
      await fileService.write(editing.path, editing.content);
      toast.success("File saved");
      setEditing(null);
    } catch (err) {
      toast.error(err instanceof ApiError ? err.message : "Failed to save file");
    } finally {
      setSaving(false);
    }
  };

  const deleteEntry = async (entry: FileEntry) => {
    try {
      await fileService.remove(entry.path);
      toast.success(`Deleted ${entry.name}`);
      load(dir);
    } catch (err) {
      toast.error(err instanceof ApiError ? err.message : "Failed to delete");
    }
  };

  const goUp = () => {
    if (dir === "/") return;
    const parent = dir.split("/").slice(0, -1).join("/") || "/";
    setDir(parent);
  };

  return (
    <AppShell title="File Manager">
      <Topbar title="File Manager" />
      <main className="flex-1 p-6">
        <Card>
          <CardHeader>
            <CardTitle>{dir}</CardTitle>
            <Button variant="outline" onClick={goUp} disabled={dir === "/"}>
              <ArrowLeft className="h-4 w-4" /> Up
            </Button>
          </CardHeader>

          {!entries && !error ? (
            <FullPageLoader label="Loading files..." />
          ) : error ? (
            <ErrorState message={error} onRetry={() => load(dir)} />
          ) : (
            <div className="divide-y divide-bg-border">
              {entries!.length === 0 && (
                <p className="py-6 text-center text-sm text-gray-500">This folder is empty.</p>
              )}
              {entries!.map((entry) => (
                <div
                  key={entry.path}
                  className="flex items-center justify-between py-2.5 hover:bg-bg-soft"
                >
                  <button
                    className="flex flex-1 items-center gap-3 text-left"
                    onClick={() => openEntry(entry)}
                  >
                    {entry.type === "directory" ? (
                      <Folder className="h-4 w-4 text-brand" />
                    ) : (
                      <FileIcon className="h-4 w-4 text-gray-500" />
                    )}
                    <span className="text-sm text-gray-200">{entry.name}</span>
                  </button>
                  <div className="flex items-center gap-3">
                    <span className="text-xs text-gray-500">{formatBytes(entry.sizeBytes)}</span>
                    <Button variant="ghost" onClick={() => deleteEntry(entry)} aria-label="Delete">
                      <Trash2 className="h-4 w-4 text-red-400" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>

        {editing && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
            <div className="flex max-h-[80vh] w-full max-w-2xl flex-col rounded-xl border border-bg-border bg-bg-card p-5">
              <div className="mb-3 flex items-center justify-between">
                <p className="font-mono text-sm text-gray-300">{editing.path}</p>
                <Button variant="ghost" onClick={() => setEditing(null)} aria-label="Close">
                  <X className="h-4 w-4" />
                </Button>
              </div>
              <textarea
                className="scrollbar-thin flex-1 resize-none rounded-lg border border-bg-border bg-black/40 p-3 font-mono text-xs text-gray-200 outline-none focus:border-brand"
                rows={18}
                value={editing.content}
                onChange={(e) => setEditing({ ...editing, content: e.target.value })}
              />
              <div className="mt-3 flex justify-end gap-2">
                <Button variant="outline" onClick={() => setEditing(null)}>
                  Cancel
                </Button>
                <Button onClick={saveFile} loading={saving}>
                  <Save className="h-4 w-4" /> Save
                </Button>
              </div>
            </div>
          </div>
        )}
      </main>
    </AppShell>
  );
}
