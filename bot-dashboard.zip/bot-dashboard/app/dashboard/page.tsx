import { AppShell } from "@/components/layout/app-shell";
import { Topbar } from "@/components/layout/topbar";
import { StatusCard } from "@/components/dashboard/status-card";
import { StatsCard } from "@/components/dashboard/stats-card";
import { CountCards } from "@/components/dashboard/count-cards";
import { QrPanel } from "@/components/dashboard/qr-panel";
import { LogConsole } from "@/components/dashboard/log-console";

export default function DashboardPage() {
  return (
    <AppShell title="Dashboard">
      <Topbar title="Dashboard" />
      <main className="flex-1 space-y-6 p-6">
        <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
          <StatusCard />
          <QrPanel />
        </div>
        <StatsCard />
        <CountCards />
        <LogConsole />
      </main>
    </AppShell>
  );
}
