import Link from "next/link";

export default function NotFound() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-3 bg-bg text-center">
      <h2 className="text-lg font-semibold text-gray-100">Page not found</h2>
      <Link href="/dashboard" className="text-sm text-brand hover:underline">
        Back to dashboard
      </Link>
    </div>
  );
}
