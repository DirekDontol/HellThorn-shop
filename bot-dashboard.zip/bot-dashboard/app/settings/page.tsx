"use client";

import { useState } from "react";
import { Save, Wifi, KeyRound } from "lucide-react";
import { toast } from "sonner";
import { AppShell } from "@/components/layout/app-shell";
import { Topbar } from "@/components/layout/topbar";
import { Card, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { botService } from "@/lib/services/bot-service";
import { ApiError } from "@/lib/api-client";

// NOTE: Base URL and bearer token are server-side env vars (NEXT_PUBLIC_API_BASE_URL,
// API_BEARER_TOKEN) read by the /api/proxy route, since the token must never reach
// the browser. This page lets the admin verify connectivity and documents how to
// change those values on the hosting platform (Vercel project settings).
export default function SettingsPage() {
  const [testing, setTesting] = useState(false);

  const testConnection = async () => {
    setTesting(true);
    try {
      await botService.getStatus();
      toast.success("Connection to bot API successful");
    } catch (err) {
      toast.error(err instanceof ApiError ? err.message : "Connection failed");
    } finally {
      setTesting(false);
    }
  };

  return (
    <AppShell title="API Settings">
      <Topbar title="API Settings" />
      <main className="flex-1 space-y-6 p-6">
        <Card className="max-w-2xl">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Wifi className="h-4 w-4" /> Connection
            </CardTitle>
          </CardHeader>
          <div className="space-y-4 text-sm text-gray-300">
            <p>
              The dashboard talks to your Termux bot through a server-side proxy, so the
              API key never reaches the browser. Configure these as environment
              variables on your Vercel project (Project → Settings → Environment
              Variables), then redeploy:
            </p>
            <div className="space-y-2 rounded-lg border border-bg-border bg-bg-soft p-4 font-mono text-xs">
              <p>NEXT_PUBLIC_API_BASE_URL=https://your-termux-tunnel</p>
              <p>API_BEARER_TOKEN=••••••••••••••••</p>
            </div>
            <Button onClick={testConnection} loading={testing}>
              <KeyRound className="h-4 w-4" /> Test Connection
            </Button>
          </div>
        </Card>

        <Card className="max-w-2xl">
          <CardHeader>
            <CardTitle>Admin Credentials</CardTitle>
          </CardHeader>
          <p className="text-sm text-gray-400">
            Dashboard login credentials (ADMIN_USERNAME / ADMIN_PASSWORD) and the
            session signing secret (SESSION_SECRET) are also set as environment
            variables for security — they are intentionally not editable from the UI.
          </p>
          <div className="mt-4 flex items-center gap-2 text-xs text-gray-500">
            <Save className="h-3.5 w-3.5" /> Changes to these require a redeploy.
          </div>
        </Card>
      </main>
    </AppShell>
  );
}
