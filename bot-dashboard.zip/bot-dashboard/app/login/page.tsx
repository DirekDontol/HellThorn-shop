"use client";

import { useState, FormEvent } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { Bot, Lock, User } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";

export default function LoginPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      });
      const json = await res.json();
      if (!res.ok || !json.ok) {
        throw new Error(json.error || "Login failed");
      }
      toast.success("Welcome back!");
      router.push(searchParams.get("next") || "/dashboard");
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Login failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-bg px-4">
      <div className="w-full max-w-sm rounded-2xl border border-bg-border bg-bg-card p-8 shadow-glow">
        <div className="mb-6 flex flex-col items-center gap-2">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-brand/15 text-brand">
            <Bot className="h-6 w-6" />
          </div>
          <h1 className="text-lg font-semibold text-gray-100">Bot Control Dashboard</h1>
          <p className="text-xs text-gray-500">Sign in to manage your Discord & WhatsApp bots</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="mb-1.5 block text-xs font-medium text-gray-400">Username</label>
            <div className="flex items-center gap-2 rounded-lg border border-bg-border bg-bg-soft px-3 py-2">
              <User className="h-4 w-4 text-gray-500" />
              <input
                className="w-full bg-transparent text-sm text-gray-100 outline-none"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                autoComplete="username"
                required
              />
            </div>
          </div>
          <div>
            <label className="mb-1.5 block text-xs font-medium text-gray-400">Password</label>
            <div className="flex items-center gap-2 rounded-lg border border-bg-border bg-bg-soft px-3 py-2">
              <Lock className="h-4 w-4 text-gray-500" />
              <input
                type="password"
                className="w-full bg-transparent text-sm text-gray-100 outline-none"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoComplete="current-password"
                required
              />
            </div>
          </div>

          {error && <p className="text-xs text-red-400">{error}</p>}

          <Button type="submit" loading={loading} className="w-full justify-center">
            Sign In
          </Button>
        </form>
      </div>
    </div>
  );
}
