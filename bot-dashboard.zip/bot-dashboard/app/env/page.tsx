"use client";

import { useEffect, useState } from "react";
import { Plus, Trash2, Save } from "lucide-react";
import { toast } from "sonner";
import { AppShell } from "@/components/layout/app-shell";
import { Topbar } from "@/components/layout/topbar";
import { Card, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FullPageLoader } from "@/components/ui/loaders";
import { ErrorState } from "@/components/ui/error-state";
import { envService } from "@/lib/services/extra-service";
import { ApiError } from "@/lib/api-client";
import type { EnvVar } from "@/types";

export default function EnvPage() {
  const [vars, setVars] = useState<EnvVar[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const load = async () => {
    setError(null);
    try {
      setVars(await envService.list());
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Failed to load .env");
    }
  };

  useEffect(() => {
    load();
  }, []);

  const update = (i: number, field: keyof EnvVar, value: string) => {
    setVars((prev) => {
      if (!prev) return prev;
      const next = [...prev];
      next[i] = { ...next[i], [field]: value };
      return next;
    });
  };

  const remove = (i: number) => {
    setVars((prev) => (prev ? prev.filter((_, idx) => idx !== i) : prev));
  };

  const addRow = () => {
    setVars((prev) => [...(prev ?? []), { key: "", value: "" }]);
  };

  const save = async () => {
    if (!vars) return;
    setSaving(true);
    try {
      await envService.update(vars);
      toast.success(".env updated. Restart the bot to apply changes.");
    } catch (err) {
      toast.error(err instanceof ApiError ? err.message : "Failed to save .env");
    } finally {
      setSaving(false);
    }
  };

  return (
    <AppShell title="Environment Variables">
      <Topbar title="Environment Variables" />
      <main className="flex-1 p-6">
        <Card>
          <CardHeader>
            <CardTitle>.env Editor</CardTitle>
            <div className="flex gap-2">
              <Button variant="outline" onClick={addRow}>
                <Plus className="h-4 w-4" /> Add Variable
              </Button>
              <Button onClick={save} loading={saving}>
                <Save className="h-4 w-4" /> Save
              </Button>
            </div>
          </CardHeader>

          {!vars && !error ? (
            <FullPageLoader label="Loading environment variables..." />
          ) : error ? (
            <ErrorState message={error} onRetry={load} />
          ) : (
            <div className="space-y-2">
              {vars!.length === 0 && (
                <p className="text-sm text-gray-500">No variables yet. Add one to get started.</p>
              )}
              {vars!.map((v, i) => (
                <div key={i} className="flex items-center gap-2">
                  <input
                    className="w-1/3 rounded-lg border border-bg-border bg-bg-soft px-3 py-2 font-mono text-xs text-gray-200 outline-none focus:border-brand"
                    value={v.key}
                    placeholder="KEY"
                    onChange={(e) => update(i, "key", e.target.value)}
                  />
                  <input
                    className="flex-1 rounded-lg border border-bg-border bg-bg-soft px-3 py-2 font-mono text-xs text-gray-200 outline-none focus:border-brand"
                    value={v.value}
                    placeholder="value"
                    onChange={(e) => update(i, "value", e.target.value)}
                  />
                  <Button variant="ghost" onClick={() => remove(i)} aria-label="Remove">
                    <Trash2 className="h-4 w-4 text-red-400" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </Card>
      </main>
    </AppShell>
  );
}
