import type { Metadata } from "next";
import { Toaster } from "sonner";
import { ThemeProvider } from "@/hooks/use-theme";
import "./globals.css";

export const metadata: Metadata = {
  title: "Bot Control Dashboard",
  description: "Control panel for Discord & WhatsApp bots running on Termux",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="dark">
      <body>
        <ThemeProvider>
          {children}
          <Toaster
            position="top-right"
            theme="dark"
            toastOptions={{
              style: {
                background: "#161a22",
                border: "1px solid #222632",
                color: "#f3f4f6",
              },
            }}
          />
        </ThemeProvider>
      </body>
    </html>
  );
}
