import { NextRequest, NextResponse } from "next/server";

// Lightweight gate: presence-only check on the session cookie (Edge runtime
// can't use Node's crypto module the same way our session.ts does, so full
// signature verification happens again inside server components/routes).
const COOKIE_NAME = "bot_dash_session";
const PROTECTED_PREFIXES = ["/dashboard", "/settings", "/env", "/files"];

export function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;
  const isProtected = PROTECTED_PREFIXES.some((p) => pathname.startsWith(p));
  if (!isProtected) return NextResponse.next();

  const hasCookie = req.cookies.has(COOKIE_NAME);
  if (!hasCookie) {
    const loginUrl = new URL("/login", req.url);
    loginUrl.searchParams.set("next", pathname);
    return NextResponse.redirect(loginUrl);
  }
  return NextResponse.next();
}

export const config = {
  matcher: ["/dashboard/:path*", "/settings/:path*", "/env/:path*", "/files/:path*"],
};
