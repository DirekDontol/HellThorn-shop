import { cn } from "@/lib/utils";
import type { BotState } from "@/types";

const STATE_STYLES: Record<BotState, string> = {
  online: "bg-status-online/15 text-status-online border-status-online/30",
  offline: "bg-status-offline/15 text-status-offline border-status-offline/30",
  starting: "bg-status-starting/15 text-status-starting border-status-starting/30",
  stopping: "bg-status-stopping/15 text-status-stopping border-status-stopping/30",
};

const STATE_LABELS: Record<BotState, string> = {
  online: "Online",
  offline: "Offline",
  starting: "Starting",
  stopping: "Stopping",
};

export function StatusBadge({ state }: { state: BotState }) {
  const pulsing = state === "starting" || state === "stopping";
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-medium",
        STATE_STYLES[state],
      )}
    >
      <span
        className={cn(
          "h-1.5 w-1.5 rounded-full bg-current",
          pulsing && "animate-pulseSoft",
        )}
      />
      {STATE_LABELS[state]}
    </span>
  );
}
