import { Sidebar } from "./sidebar";

export function AppShell({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex min-h-screen bg-bg">
      <Sidebar />
      <div className="flex min-h-screen flex-1 flex-col">
        {/* Topbar is rendered per-page so it can be a client component
            while this shell stays a server component. */}
        {children}
      </div>
    </div>
  );
}
