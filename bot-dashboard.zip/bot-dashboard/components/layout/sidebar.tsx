"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { LayoutDashboard, Settings, FileCode2, FolderOpen, Bot } from "lucide-react";
import { cn } from "@/lib/utils";

const NAV_ITEMS = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/env", label: "Environment", icon: FileCode2 },
  { href: "/files", label: "File Manager", icon: FolderOpen },
  { href: "/settings", label: "API Settings", icon: Settings },
];

export function Sidebar() {
  const pathname = usePathname();

  return (
    <aside className="hidden w-60 shrink-0 flex-col border-r border-bg-border bg-bg-card md:flex">
      <div className="flex items-center gap-2 border-b border-bg-border px-5 py-5">
        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-brand/15 text-brand">
          <Bot className="h-5 w-5" />
        </div>
        <span className="text-sm font-semibold text-gray-100">Bot Control</span>
      </div>
      <nav className="flex-1 space-y-1 px-3 py-4">
        {NAV_ITEMS.map(({ href, label, icon: Icon }) => {
          const active = pathname === href || pathname.startsWith(`${href}/`);
          return (
            <Link
              key={href}
              href={href}
              className={cn(
                "flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors",
                active
                  ? "bg-brand/15 text-brand font-medium"
                  : "text-gray-400 hover:bg-bg-soft hover:text-gray-200",
              )}
            >
              <Icon className="h-4 w-4" />
              {label}
            </Link>
          );
        })}
      </nav>
      <div className="border-t border-bg-border p-4 text-xs text-gray-500">
        Connected via Termux REST API
      </div>
    </aside>
  );
}
