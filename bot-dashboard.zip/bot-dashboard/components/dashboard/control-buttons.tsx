"use client";

import { Play, Square, RotateCw, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useBotActions } from "@/hooks/use-bot";

export function ControlButtons({ onAction }: { onAction: () => void }) {
  const { pending, start, stop, restart, forceRestart } = useBotActions(onAction);

  return (
    <div className="flex flex-wrap gap-2">
      <Button variant="primary" loading={pending === "start"} onClick={start}>
        <Play className="h-4 w-4" /> Start
      </Button>
      <Button variant="danger" loading={pending === "stop"} onClick={stop}>
        <Square className="h-4 w-4" /> Stop
      </Button>
      <Button variant="outline" loading={pending === "restart"} onClick={restart}>
        <RotateCw className="h-4 w-4" /> Restart
      </Button>
      <Button variant="warning" loading={pending === "forceRestart"} onClick={forceRestart}>
        <Zap className="h-4 w-4" /> Force Restart
      </Button>
    </div>
  );
}
