"use client";

import { Card, CardHeader, CardTitle } from "@/components/ui/card";
import { StatusBadge } from "@/components/ui/status-badge";
import { Skeleton } from "@/components/ui/loaders";
import { ErrorState } from "@/components/ui/error-state";
import { ControlButtons } from "./control-buttons";
import { useBotStatus } from "@/hooks/use-bot";
import { formatUptime } from "@/lib/utils";

export function StatusCard() {
  const { data, error, loading, refresh } = useBotStatus();

  const sinceMs = data?.since ? Date.now() - new Date(data.since).getTime() : null;

  return (
    <Card className="md:col-span-2">
      <CardHeader>
        <CardTitle>Bot Status</CardTitle>
        {!loading && !error && (
          <span className="text-xs text-gray-500">Auto-refreshing every 5s</span>
        )}
      </CardHeader>

      {loading && !data ? (
        <Skeleton className="h-20 w-full" />
      ) : error && !data ? (
        <ErrorState message={error} onRetry={refresh} />
      ) : (
        <div className="space-y-5">
          <div className="grid grid-cols-2 gap-4">
            <div className="rounded-lg border border-bg-border bg-bg-soft p-4">
              <p className="mb-2 text-xs text-gray-500">Discord Bot</p>
              <StatusBadge state={data!.discord} />
            </div>
            <div className="rounded-lg border border-bg-border bg-bg-soft p-4">
              <p className="mb-2 text-xs text-gray-500">WhatsApp Bot</p>
              <StatusBadge state={data!.whatsapp} />
            </div>
          </div>
          {sinceMs !== null && (
            <p className="text-xs text-gray-500">
              Current state for {formatUptime(sinceMs / 1000)}
            </p>
          )}
          <div className="border-t border-bg-border pt-4">
            <ControlButtons onAction={refresh} />
          </div>
        </div>
      )}
    </Card>
  );
}
