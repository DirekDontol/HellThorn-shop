"use client";

import { useEffect, useRef, useState } from "react";
import { Terminal, Pause, Play, Trash2 } from "lucide-react";
import { Card, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ErrorState } from "@/components/ui/error-state";
import { useLogs } from "@/hooks/use-bot";
import { cn } from "@/lib/utils";
import type { LogEntry } from "@/types";

const LEVEL_COLORS: Record<LogEntry["level"], string> = {
  info: "text-gray-300",
  warn: "text-amber-400",
  error: "text-red-400",
  debug: "text-gray-500",
};

export function LogConsole() {
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [cleared, setCleared] = useState(false);
  const { data, error, refresh } = useLogs(autoRefresh);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current && autoRefresh) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [data, autoRefresh]);

  const logs = cleared ? [] : data ?? [];

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Terminal className="h-4 w-4" /> Live Console
        </CardTitle>
        <div className="flex items-center gap-2">
          <Button variant="ghost" onClick={() => setCleared(true)} aria-label="Clear console">
            <Trash2 className="h-4 w-4" />
          </Button>
          <Button
            variant="outline"
            onClick={() => {
              setAutoRefresh((v) => !v);
              setCleared(false);
            }}
          >
            {autoRefresh ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
            {autoRefresh ? "Pause" : "Resume"}
          </Button>
        </div>
      </CardHeader>

      {error && logs.length === 0 ? (
        <ErrorState message={error} onRetry={refresh} />
      ) : (
        <div
          ref={scrollRef}
          className="scrollbar-thin h-72 overflow-y-auto rounded-lg border border-bg-border bg-black/40 p-3 font-mono text-xs"
        >
          {logs.length === 0 ? (
            <p className="text-gray-600">No log entries yet.</p>
          ) : (
            logs.map((log) => (
              <div key={log.id} className="mb-1 flex gap-2">
                <span className="shrink-0 text-gray-600">
                  {new Date(log.timestamp).toLocaleTimeString()}
                </span>
                <span className="shrink-0 text-gray-600">[{log.source}]</span>
                <span className={cn(LEVEL_COLORS[log.level])}>{log.message}</span>
              </div>
            ))
          )}
        </div>
      )}
    </Card>
  );
}
