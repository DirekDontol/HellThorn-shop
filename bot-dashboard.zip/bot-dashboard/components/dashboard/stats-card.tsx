"use client";

import { Cpu, MemoryStick, Clock } from "lucide-react";
import { Card, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/loaders";
import { ErrorState } from "@/components/ui/error-state";
import { useBotStats } from "@/hooks/use-bot";
import { formatMb, formatUptime, cn } from "@/lib/utils";

function Metric({
  icon: Icon,
  label,
  value,
  sub,
  barPercent,
}: {
  icon: typeof Cpu;
  label: string;
  value: string;
  sub?: string;
  barPercent?: number;
}) {
  return (
    <div className="rounded-lg border border-bg-border bg-bg-soft p-4">
      <div className="mb-2 flex items-center gap-2 text-xs text-gray-500">
        <Icon className="h-3.5 w-3.5" /> {label}
      </div>
      <p className="text-xl font-semibold text-gray-100">{value}</p>
      {sub && <p className="mt-0.5 text-xs text-gray-500">{sub}</p>}
      {barPercent !== undefined && (
        <div className="mt-3 h-1.5 w-full overflow-hidden rounded-full bg-bg-border">
          <div
            className={cn(
              "h-full rounded-full transition-all",
              barPercent > 85 ? "bg-red-500" : barPercent > 60 ? "bg-amber-500" : "bg-brand",
            )}
            style={{ width: `${Math.min(barPercent, 100)}%` }}
          />
        </div>
      )}
    </div>
  );
}

export function StatsCard() {
  const { data, error, loading, refresh } = useBotStats();

  return (
    <Card>
      <CardHeader>
        <CardTitle>Resource Usage</CardTitle>
      </CardHeader>
      {loading && !data ? (
        <div className="grid grid-cols-3 gap-3">
          <Skeleton className="h-24" />
          <Skeleton className="h-24" />
          <Skeleton className="h-24" />
        </div>
      ) : error && !data ? (
        <ErrorState message={error} onRetry={refresh} />
      ) : (
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
          <Metric
            icon={Cpu}
            label="CPU"
            value={`${data!.cpuPercent.toFixed(1)}%`}
            barPercent={data!.cpuPercent}
          />
          <Metric
            icon={MemoryStick}
            label="RAM"
            value={formatMb(data!.ramUsedMb)}
            sub={`of ${formatMb(data!.ramTotalMb)}`}
            barPercent={(data!.ramUsedMb / data!.ramTotalMb) * 100}
          />
          <Metric icon={Clock} label="Uptime" value={formatUptime(data!.uptimeSeconds)} />
        </div>
      )}
    </Card>
  );
}
