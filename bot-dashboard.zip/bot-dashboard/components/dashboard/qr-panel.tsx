"use client";

import { QrCode, CheckCircle2 } from "lucide-react";
import { Card, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/loaders";
import { ErrorState } from "@/components/ui/error-state";
import { useQr } from "@/hooks/use-bot";

export function QrPanel() {
  const { data, error, loading, refresh } = useQr();

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <QrCode className="h-4 w-4" /> WhatsApp Login
        </CardTitle>
      </CardHeader>

      {loading && !data ? (
        <Skeleton className="mx-auto h-48 w-48" />
      ) : error && !data ? (
        <ErrorState message={error} onRetry={refresh} />
      ) : data!.authenticated ? (
        <div className="flex flex-col items-center justify-center gap-2 py-8 text-center">
          <CheckCircle2 className="h-10 w-10 text-status-online" />
          <p className="text-sm text-gray-300">WhatsApp is authenticated</p>
        </div>
      ) : data!.qr ? (
        <div className="flex flex-col items-center gap-3">
          <img
            src={data!.qr}
            alt="WhatsApp QR code"
            className="h-48 w-48 rounded-lg border border-bg-border bg-white p-2"
          />
          <p className="text-xs text-gray-500">
            Scan with WhatsApp → Linked Devices. Refreshes automatically.
          </p>
        </div>
      ) : (
        <p className="py-8 text-center text-sm text-gray-500">
          No QR code available right now.
        </p>
      )}
    </Card>
  );
}
