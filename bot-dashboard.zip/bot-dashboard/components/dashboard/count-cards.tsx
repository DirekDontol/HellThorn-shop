"use client";

import { Server, Users } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/loaders";
import { useServers, useGroups } from "@/hooks/use-bot";

export function CountCards() {
  const servers = useServers();
  const groups = useGroups();

  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
      <Card className="flex items-center gap-4">
        <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-indigo-500/15 text-indigo-400">
          <Server className="h-5 w-5" />
        </div>
        <div>
          <p className="text-xs text-gray-500">Discord Servers</p>
          {servers.loading && !servers.data ? (
            <Skeleton className="mt-1 h-6 w-10" />
          ) : (
            <p className="text-xl font-semibold text-gray-100">
              {servers.data?.count ?? "-"}
            </p>
          )}
        </div>
      </Card>
      <Card className="flex items-center gap-4">
        <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-emerald-500/15 text-emerald-400">
          <Users className="h-5 w-5" />
        </div>
        <div>
          <p className="text-xs text-gray-500">WhatsApp Groups</p>
          {groups.loading && !groups.data ? (
            <Skeleton className="mt-1 h-6 w-10" />
          ) : (
            <p className="text-xl font-semibold text-gray-100">
              {groups.data?.count ?? "-"}
            </p>
          )}
        </div>
      </Card>
    </div>
  );
}
