# Bot Control Dashboard

A modern, dark-themed dashboard (Next.js 14 + TypeScript + Tailwind) for
controlling Discord and WhatsApp bots running on Termux via REST API.

## Architecture

```
app/
  login/            Login page
  dashboard/         Main dashboard (status, stats, logs, QR, counts)
  settings/          API connection settings
  env/                .env editor
  files/              Simple file manager
  api/
    auth/login        Sets a signed session cookie
    auth/logout        Clears the session cookie
    proxy               Forwards requests to the Termux API, injects Bearer token
components/
  ui/                 Reusable primitives (Button, Card, StatusBadge, loaders, ErrorState)
  layout/              Sidebar, Topbar, AppShell
  dashboard/           Feature widgets (StatusCard, StatsCard, LogConsole, QrPanel, ...)
hooks/                 usePolling, useBotStatus/useBotStats/..., useBotActions, useTheme
lib/
  services/            One function per backend endpoint (bot-service, extra-service)
  api-client.ts        Typed fetch wrapper used by all services
  session.ts            Signed-cookie session helper
  utils.ts               cn(), formatUptime, formatMb, formatBytes
types/                  Shared TypeScript types
middleware.ts           Redirects unauthenticated users away from protected routes
```

### Why a server-side proxy?

The API key/Bearer token is configured as a **server-only** environment
variable (`API_BEARER_TOKEN`) and is only ever attached to requests inside
`app/api/proxy/route.ts`. The browser never sees it — every dashboard
component calls `/api/proxy?path=...`, which is itself gated behind the
admin session cookie before it forwards anything to your Termux device.

## Backend contract (already available on your Termux REST API)

| Method | Path        | Returns                                  |
|--------|-------------|-------------------------------------------|
| GET    | /status     | `{ discord, whatsapp, since }`             |
| POST   | /start      | `{ ok }`                                    |
| POST   | /stop       | `{ ok }`                                    |
| POST   | /restart    | `{ ok }` (body `{ force: true }` for force) |
| GET    | /logs       | `LogEntry[]`                                |
| GET    | /stats      | `{ cpuPercent, ramUsedMb, ramTotalMb, uptimeSeconds }` |
| GET    | /qr         | `{ qr, authenticated }`                     |
| GET    | /servers    | `{ count, servers[] }`                      |
| GET    | /groups     | `{ count, groups[] }`                       |

Two extra conventional endpoints are wired up for the Environment Variables
editor and File Manager (`/env`, `/files`) — see
`lib/services/extra-service.ts`. Adjust the paths there if your backend
differs; that file is the single source of truth for those two features.

See `types/index.ts` for exact response shapes.

## Local development

```bash
cp .env.example .env.local
# edit .env.local with your Termux API URL/token and admin credentials
npm install
npm run dev
```

## Deploying to Vercel

1. Push this repo to GitHub/GitLab/Bitbucket.
2. Import the project in Vercel.
3. Add the environment variables from `.env.example` in
   Project → Settings → Environment Variables.
4. Make sure your Termux device's API is reachable from the internet
   (e.g. via Cloudflare Tunnel, Tailscale Funnel, or ngrok) and use that
   URL as `NEXT_PUBLIC_API_BASE_URL`.
5. Deploy.

## Security notes

- All control/data endpoints are proxied server-side; the Bearer token
  never reaches client JS.
- Admin login uses a signed (HMAC-SHA256), httpOnly, sameSite cookie —
  no third-party auth dependency needed for a single-admin panel.
- `middleware.ts` blocks direct access to `/dashboard`, `/settings`,
  `/env`, and `/files` without a session cookie present.
- Rotate `SESSION_SECRET`, `API_BEARER_TOKEN`, and `ADMIN_PASSWORD`
  periodically; they are read only from environment variables.
